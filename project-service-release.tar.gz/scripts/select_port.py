import json
import os
import socket
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def select_port(start: int = 18080) -> int:
    port = start
    while port <= 65535:
        with socket.socket() as sock:
            try:
                sock.bind(("0.0.0.0", port))
                return port
            except OSError:
                port += 1
    raise RuntimeError("No free TCP port available")


def main() -> None:
    port = select_port()
    version = os.environ.get("DEPLOY_VERSION", datetime.now(UTC).strftime("%Y%m%d%H%M%S"))
    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        commit = "unversioned-source"
    payload = {
        "version": version, "commit": commit, "source": "project-service",
        "port": port, "selected_at": datetime.now(UTC).isoformat(),
    }
    _atomic_write(ROOT / "deploy.env", f"COMPOSE_PROJECT_NAME=wkdevops-project-service\nPROJECT_SERVICE_PORT={port}\n")
    _atomic_write(ROOT / "deployment.json", json.dumps(payload, indent=2) + "\n")


def _atomic_write(path: Path, content: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


if __name__ == "__main__":
    main()
