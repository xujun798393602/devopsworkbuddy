#!/usr/bin/env bash
set -euo pipefail
ROOT=/project/devops-platform
VERSION=${1:?usage: deploy.sh VERSION}
RELEASE="$ROOT/releases/$VERSION"
test -f "$RELEASE/compose.debug.yaml"
cd "$RELEASE"
python3 scripts/select_port.py
if [[ -L "$ROOT/current" ]]; then ln -sfn "$(readlink -f "$ROOT/current")" "$ROOT/previous"; fi
COMPOSE_PROJECT_NAME=wkdevops-project-service docker compose --env-file deploy.env -f compose.debug.yaml up --build -d
ln -sfn "$RELEASE" "$ROOT/current"
