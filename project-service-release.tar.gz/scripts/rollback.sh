#!/usr/bin/env bash
set -euo pipefail
ROOT=/project/devops-platform
PREVIOUS=$(readlink -f "$ROOT/previous")
test -f "$PREVIOUS/compose.debug.yaml"
cd "$PREVIOUS"
COMPOSE_PROJECT_NAME=wkdevops-project-service docker compose --env-file deploy.env -f compose.debug.yaml up --build -d
ln -sfn "$PREVIOUS" "$ROOT/current"
