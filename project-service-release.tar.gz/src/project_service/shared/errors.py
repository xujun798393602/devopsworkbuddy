from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class AppError(Exception):
    message: str
    error_code: str
    status_code: int
    error_type: str = "about:blank"
    errors: list[dict[str, Any]] | None = None


class ValidationError(AppError):
    def __init__(self, message: str, errors: list[dict[str, Any]] | None = None) -> None:
        super().__init__(message, "VALIDATION_ERROR", 422, errors=errors)


class NotFoundError(AppError):
    def __init__(self, resource: str, resource_id: str) -> None:
        super().__init__(f"{resource} not found: {resource_id}", "RESOURCE_NOT_FOUND", 404)


class ForbiddenError(AppError):
    def __init__(self, message: str = "Access to this project is forbidden") -> None:
        super().__init__(message, "PROJECT_ACCESS_FORBIDDEN", 403)


class ConflictError(AppError):
    def __init__(self, message: str, error_code: str = "RESOURCE_CONFLICT") -> None:
        super().__init__(message, error_code, 409)
