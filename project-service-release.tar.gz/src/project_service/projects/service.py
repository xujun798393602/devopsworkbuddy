import hashlib
import json
import unicodedata
from collections.abc import Callable
from uuid import uuid4

from project_service.persistence.uow import UnitOfWork
from project_service.projects.events import project_created_event
from project_service.projects.models import Project
from project_service.shared.errors import (
    ConflictError,
    ForbiddenError,
    NotFoundError,
    ValidationError,
)
from project_service.shared.request_context import RequestContext

EventSink = Callable[[dict[str, object]], None]
UnitOfWorkFactory = Callable[[], UnitOfWork]
_HASH_PREFIX = "v1\nPOST /api/v1/projects\n"


class ProjectService:
    """Coordinates project use cases without depending on SQLAlchemy."""

    def __init__(self, uow_factory: UnitOfWorkFactory, event_sink: EventSink) -> None:
        self._uow_factory = uow_factory
        self._event_sink = event_sink

    def create_project(
        self, payload: dict[str, object], context: RequestContext, idempotency_key: str
    ) -> Project:
        normalized = normalize_create_payload(payload, context.actor_id)
        request_hash = create_request_hash(normalized)
        scope = f"actor:{context.actor_id}"
        created = False
        with self._uow_factory() as uow:
            uow.idempotency.lock(scope, idempotency_key)
            record = uow.idempotency.get(scope, idempotency_key)
            if record is not None:
                if record.request_hash != request_hash:
                    raise ConflictError(
                        "Idempotency-Key was already used with a different request",
                        "IDEMPOTENCY_KEY_CONFLICT",
                    )
                if record.status != "completed" or not record.resource_id:
                    raise ConflictError("The original request is still processing")
                project = uow.projects.get(record.resource_id)
                if project is None:
                    raise RuntimeError("Completed idempotency record references a missing project")
                return project
            record = uow.idempotency.add_processing(scope, idempotency_key, request_hash)
            project = Project.create(
                project_id=str(uuid4()), business_no=uow.projects.next_business_no(),
                name=normalized["name"], description=normalized["description"],
                owner_id=normalized["owner_id"],
            )
            uow.projects.add(project)
            uow.idempotency.complete(record, project.id, 201)
            uow.commit()
            created = True
        if created:
            try:
                self._event_sink(project_created_event(project, context))
            except Exception:
                pass
        return project

    def get_project(self, project_id: str, actor_id: str) -> Project:
        with self._uow_factory() as uow:
            project = uow.projects.get(project_id)
        if project is None:
            raise NotFoundError("Project", project_id)
        if project.owner_id != actor_id:
            raise ForbiddenError()
        return project

    def list_projects(self, actor_id: str) -> list[Project]:
        with self._uow_factory() as uow:
            return uow.projects.list_for_actor(actor_id)


def normalize_create_payload(payload: dict[str, object], actor_id: str) -> dict[str, str]:
    """Strictly validate and NFC-normalize the canonical create command fields."""
    allowed_fields = {"name", "description", "owner_id"}
    unknown_fields = sorted(payload.keys() - allowed_fields)
    if unknown_fields:
        raise ValidationError(
            "Request contains unknown fields",
            [{"field": field, "message": "Unknown field"} for field in unknown_fields],
        )
    errors: list[dict[str, str]] = []
    name_value = payload.get("name")
    description_value = payload.get("description", "")
    owner_value = payload.get("owner_id", actor_id)
    if not isinstance(name_value, str):
        errors.append({"field": "name", "message": "Must be a string"})
    if not isinstance(description_value, str):
        errors.append({"field": "description", "message": "Must be a string"})
    if not isinstance(owner_value, str):
        errors.append({"field": "owner_id", "message": "Must be a string"})
    if errors:
        raise ValidationError("Request fields have invalid types", errors)
    name = _normalize(name_value)
    description = _normalize(description_value)
    owner_id = _normalize(owner_value)
    if not name:
        errors.append({"field": "name", "message": "Required"})
    elif len(name) > 120:
        errors.append({"field": "name", "message": "Must not exceed 120 characters"})
    if not owner_id:
        errors.append({"field": "owner_id", "message": "Must not be empty"})
    if errors:
        raise ValidationError("Request fields are invalid", errors)
    return {"name": name, "description": description, "owner_id": owner_id}


def create_request_hash(normalized_payload: dict[str, str]) -> str:
    canonical = json.dumps(
        normalized_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(f"{_HASH_PREFIX}{canonical}".encode()).hexdigest()


def _normalize(value: str) -> str:
    return unicodedata.normalize("NFC", value).strip()
