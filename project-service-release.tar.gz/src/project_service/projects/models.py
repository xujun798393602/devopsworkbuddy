from dataclasses import asdict, dataclass
from datetime import UTC, datetime


@dataclass(slots=True)
class Project:
    id: str
    business_no: str
    name: str
    description: str
    owner_id: str
    status: str
    version: int
    created_at: datetime
    updated_at: datetime

    def to_dict(self) -> dict[str, object]:
        data = asdict(self)
        data["created_at"] = self.created_at.isoformat()
        data["updated_at"] = self.updated_at.isoformat()
        return data

    @classmethod
    def create(
        cls,
        *,
        project_id: str,
        business_no: str,
        name: str,
        description: str,
        owner_id: str,
    ) -> "Project":
        now = datetime.now(UTC)
        return cls(
            id=project_id,
            business_no=business_no,
            name=name,
            description=description,
            owner_id=owner_id,
            status="active",
            version=1,
            created_at=now,
            updated_at=now,
        )
