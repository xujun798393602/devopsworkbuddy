from typing import Protocol

from project_service.projects.models import Project


class ProjectRepository(Protocol):
    """Persistence-neutral project repository contract."""

    def add(self, project: Project) -> Project: ...

    def get(self, project_id: str) -> Project | None: ...

    def list_for_actor(self, actor_id: str) -> list[Project]: ...

    def next_business_no(self) -> str: ...
