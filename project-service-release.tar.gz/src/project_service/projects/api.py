from flask import Blueprint, current_app, jsonify, request

from project_service.projects.service import ProjectService
from project_service.shared.errors import ValidationError
from project_service.shared.request_context import RequestContext

projects_blueprint = Blueprint("projects", __name__, url_prefix="/api/v1/projects")


def _service() -> ProjectService:
    return current_app.extensions["project_service"]


@projects_blueprint.post("")
def create_project():
    idempotency_key = request.headers.get("Idempotency-Key", "").strip()
    if not idempotency_key or len(idempotency_key) > 255:
        raise ValidationError(
            "Idempotency-Key header must contain 1 to 255 characters",
            [{"field": "Idempotency-Key", "message": "Must contain 1 to 255 characters"}],
        )
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise ValidationError("Request body must be a JSON object")
    context = RequestContext.from_request(request)
    project = _service().create_project(payload, context, idempotency_key)
    return jsonify({"data": project.to_dict(), "meta": {"trace_id": context.trace_id}}), 201


@projects_blueprint.get("")
def list_projects():
    context = RequestContext.from_request(request)
    projects = [project.to_dict() for project in _service().list_projects(context.actor_id)]
    return jsonify({"data": projects, "meta": {"trace_id": context.trace_id}})


@projects_blueprint.get("/<project_id>")
def get_project(project_id: str):
    context = RequestContext.from_request(request)
    project = _service().get_project(project_id, context.actor_id)
    return jsonify({"data": project.to_dict(), "meta": {"trace_id": context.trace_id}})
