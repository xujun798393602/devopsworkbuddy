"""SQLAlchemy persistence adapters."""
