from types import TracebackType
from typing import Protocol, Self

from sqlalchemy.orm import Session

from project_service.database import Database
from project_service.idempotency.repository import IdempotencyRepository
from project_service.persistence.idempotency import SqlAlchemyIdempotencyRepository
from project_service.persistence.repositories import SqlAlchemyProjectRepository
from project_service.projects.repository import ProjectRepository


class UnitOfWork(Protocol):
    projects: ProjectRepository
    idempotency: IdempotencyRepository

    def __enter__(self) -> Self: ...
    def __exit__(self, exc_type, exc, traceback) -> None: ...
    def commit(self) -> None: ...


class SqlAlchemyUnitOfWork:
    """Transaction boundary with one Session per use."""

    def __init__(self, database: Database) -> None:
        self._database = database
        self._session: Session | None = None

    def __enter__(self) -> Self:
        self._session = self._database.sessions()
        self.projects = SqlAlchemyProjectRepository(self._session)
        self.idempotency = SqlAlchemyIdempotencyRepository(self._session)
        return self

    def commit(self) -> None:
        if self._session is None:
            raise RuntimeError("Unit of work is not active")
        self._session.commit()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self._session is not None:
            if exc_type is not None or self._session.in_transaction():
                self._session.rollback()
            self._session.close()


class SqlAlchemyUnitOfWorkFactory:
    """Creates independent transaction boundaries."""

    def __init__(self, database: Database) -> None:
        self._database = database

    def __call__(self) -> SqlAlchemyUnitOfWork:
        return SqlAlchemyUnitOfWork(self._database)
