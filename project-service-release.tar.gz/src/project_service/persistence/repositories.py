from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from project_service.persistence.tables import ProjectRow
from project_service.projects.models import Project


class SqlAlchemyProjectRepository:
    """SQLAlchemy implementation of the project repository."""

    def __init__(self, session: Session) -> None:
        self._session = session

    def add(self, project: Project) -> Project:
        self._session.add(
            ProjectRow(
                id=UUID(project.id), business_no=project.business_no, name=project.name,
                description=project.description, owner_id=project.owner_id, status=project.status,
                version=project.version, created_at=project.created_at, updated_at=project.updated_at,
            )
        )
        return project

    def get(self, project_id: str) -> Project | None:
        try:
            row = self._session.get(ProjectRow, UUID(project_id))
        except ValueError:
            return None
        return _to_domain(row) if row else None

    def list_for_actor(self, actor_id: str) -> list[Project]:
        statement = (
            select(ProjectRow)
            .where(ProjectRow.owner_id == actor_id)
            .order_by(ProjectRow.created_at.desc())
        )
        return [_to_domain(row) for row in self._session.scalars(statement)]

    def next_business_no(self) -> str:
        sequence = self._session.execute(
            text("SELECT nextval('project_business_no_seq')")
        ).scalar_one()
        return f"PRJ-{sequence:06d}"


def _to_domain(row: ProjectRow) -> Project:
    return Project(
        id=str(row.id), business_no=row.business_no, name=row.name,
        description=row.description, owner_id=row.owner_id, status=row.status,
        version=row.version, created_at=row.created_at, updated_at=row.updated_at,
    )
