from datetime import UTC, datetime
from uuid import UUID

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from project_service.idempotency.models import IdempotencyRecord
from project_service.persistence.tables import IdempotencyRecordRow

_ADVISORY_SEED = 74839201


class SqlAlchemyIdempotencyRepository:
    """PostgreSQL transaction-locking idempotency repository."""

    def __init__(self, session: Session) -> None:
        self._session = session

    def lock(self, scope: str, key: str) -> None:
        self._session.execute(
            text("SELECT pg_advisory_xact_lock(hashtextextended(:material, :seed))"),
            {"material": f"{scope}\0{key}", "seed": _ADVISORY_SEED},
        )

    def get(self, scope: str, key: str) -> IdempotencyRecord | None:
        row = self._session.scalar(
            select(IdempotencyRecordRow).where(
                IdempotencyRecordRow.scope == scope,
                IdempotencyRecordRow.idempotency_key == key,
            )
        )
        return _to_domain(row) if row else None

    def add_processing(self, scope: str, key: str, request_hash: str) -> IdempotencyRecord:
        row = IdempotencyRecordRow(
            scope=scope, idempotency_key=key, request_hash=request_hash, status="processing"
        )
        self._session.add(row)
        return IdempotencyRecord(scope, key, request_hash, "processing")

    def complete(self, record: IdempotencyRecord, resource_id: str, status: int) -> None:
        row = self._session.scalar(
            select(IdempotencyRecordRow).where(
                IdempotencyRecordRow.scope == record.scope,
                IdempotencyRecordRow.idempotency_key == record.idempotency_key,
            )
        )
        if row is None:
            raise RuntimeError("Idempotency record disappeared during transaction")
        row.status = "completed"
        row.resource_id = UUID(resource_id)
        row.response_status = status
        row.completed_at = datetime.now(UTC)
        record.status = "completed"
        record.resource_id = resource_id
        record.response_status = status
        record.completed_at = row.completed_at


def _to_domain(row: IdempotencyRecordRow) -> IdempotencyRecord:
    return IdempotencyRecord(
        scope=row.scope, idempotency_key=row.idempotency_key, request_hash=row.request_hash,
        status=row.status, response_status=row.response_status,
        resource_id=str(row.resource_id) if row.resource_id else None,
        created_at=row.created_at, completed_at=row.completed_at,
    )
