from dataclasses import dataclass
from datetime import datetime


@dataclass(slots=True)
class IdempotencyRecord:
    """Persistence-neutral idempotency record."""

    scope: str
    idempotency_key: str
    request_hash: str
    status: str
    response_status: int | None = None
    resource_id: str | None = None
    created_at: datetime | None = None
    completed_at: datetime | None = None
