"""Idempotency domain contracts."""
