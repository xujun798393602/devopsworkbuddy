from typing import Protocol

from project_service.idempotency.models import IdempotencyRecord


class IdempotencyRepository(Protocol):
    """Idempotency persistence contract."""

    def lock(self, scope: str, key: str) -> None: ...

    def get(self, scope: str, key: str) -> IdempotencyRecord | None: ...

    def add_processing(self, scope: str, key: str, request_hash: str) -> IdempotencyRecord: ...

    def complete(self, record: IdempotencyRecord, resource_id: str, status: int) -> None: ...
